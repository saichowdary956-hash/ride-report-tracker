# RideReport Vehicle Tracker

This app uploads RideReport CSV files, tracks each vehicle separately, calculates completed hours by condition, and rebuilds a Daily Tracker Excel file from the stored data.

## Local Run

```powershell
pip install -r requirements.txt
python .\ride_report_app.py --open
```

Then open:

```text
http://127.0.0.1:8765
```

Local mode uses:

- `outputs\daily_tracker_backup.sqlite` for backup storage
- `outputs\daily_tracker_<Vehicle>.xlsx` for Excel exports
- `uploads\` for temporary uploaded CSV files

## Cloud Storage

Set `DATABASE_URL` to a PostgreSQL connection string to use cloud storage instead of the local SQLite file.

```powershell
$env:DATABASE_URL="postgresql://USER:PASSWORD@HOST:5432/postgres"
python .\ride_report_app.py
```

When `DATABASE_URL` is present, all vehicle rows, uploaded CSV records, settings, and progress data are stored in PostgreSQL. The app has no built-in CSV count limit per vehicle; storage is limited by your database plan.

## Desktop Launchers

- Use `Start_RideReport_Neon_Cloud.bat` when you want Neon Postgres as the permanent storage unit.
- Use `Start_RideReport_Offline.bat` only when you want local SQLite storage without internet.
- The app includes a `File Storage` tab for the selected vehicle, with database-backed CSV and Excel folders.

## Render Deployment

Fastest link:

```text
https://render.com/deploy?repo=https://github.com/saichowdary956-hash/ride-report-tracker
```

1. Push this folder to a GitHub repository.
2. In Render, create a new Blueprint from the GitHub repository.
3. Render reads `render.yaml`, creates the web service, creates a PostgreSQL database, and injects `DATABASE_URL` automatically.

`render.yaml` is included so Render can detect the Python service settings.

## Notes

- Select the active vehicle before uploading CSV files.
- The upload button shows the target vehicle, for example `Upload CSV Files to Jeep`.
- Excel files are generated from database data. In cloud deployment, download the Excel file instead of trying to open Excel on the server.
- The generated Excel workbook includes a `Completed So Far` sheet with target percentage, planned hours, completed duration, completed hours, remaining hours, completion percentage, and status for each progress condition.
- Keep `.env`, `outputs/`, and `uploads/` out of GitHub. They are ignored by `.gitignore`.
